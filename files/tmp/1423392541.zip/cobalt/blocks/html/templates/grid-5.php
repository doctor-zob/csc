<?php    defined('C5_EXECUTE') or die("Access Denied."); ?>

<div class="small-12 large-5 column">
  <div id="HTMLBlock<?php   echo intval($bID)?>" class="HTMLBlock">
    <?php   echo $content; ?>
  </div>
</div>