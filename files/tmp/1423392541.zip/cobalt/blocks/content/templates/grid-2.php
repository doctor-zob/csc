<?php   defined('C5_EXECUTE') or die("Access Denied."); ?>

<div class="small-12 large-2 column">
	<?php  
	$content = $controller->getContent();
	print $content;
  ?>
</div>