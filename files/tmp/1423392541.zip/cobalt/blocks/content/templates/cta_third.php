<?php   defined('C5_EXECUTE') or die("Access Denied."); ?>

<div class="small-12 large-4 column cta-third">
	<div class="cta-wrap">
	<?php  
    $content = $controller->getContent();
    print $content;
  ?>
  </div>
</div>