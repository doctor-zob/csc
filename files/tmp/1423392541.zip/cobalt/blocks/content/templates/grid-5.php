<?php   defined('C5_EXECUTE') or die("Access Denied."); ?>

<div class="small-12 large-5 column">
	<?php  
	$content = $controller->getContent();
	print $content;
  ?>
</div>