$(document).ready(function() {
	
	// initialize foundation
	$(document).foundation();

});