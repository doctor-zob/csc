$(function() {
	$("#ccm-page-edit-nav-proevents").dialog();
});