<?php    
defined('C5_EXECUTE') or die(_("Access Denied."));
Loader::model("collection_types");

$this->inc('form.php');

?>