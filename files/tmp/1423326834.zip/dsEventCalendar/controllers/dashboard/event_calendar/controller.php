<?php 

defined('C5_EXECUTE') or die("Access Denied.");

class DashboardEventCalendarController extends Controller
{

    public function view()
    {

    }

}